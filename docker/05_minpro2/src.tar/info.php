<?php
 phpinfo(); 
 ?>